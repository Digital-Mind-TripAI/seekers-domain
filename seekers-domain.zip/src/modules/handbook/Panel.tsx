export default function HandbookPanel() {
  return (
    <div style={{ padding: "1rem", color: "white" }}>
      <h2>The Seeker’s Handbook</h2>
      <p>Welcome, Seeker. Your journey begins here.</p>
    </div>
  );
}
