// src/modules/nexus/Scene.tsx

import { LandingScene } from "../../scenes/LandingScene";

export const NexusScene = () => {
  return <LandingScene />;
};
