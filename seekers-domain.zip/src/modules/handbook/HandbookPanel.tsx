export function HandbookPanel() {
  return (
    <div>
      <h1 style={{ color: "#4eff4e", marginBottom: 12 }}>Seeker’s Handbook</h1>
      <p style={{ maxWidth: 600, lineHeight: 1.6 }}>
        This will become the Nexus “home base” — the living Codex, journal, and guide.
        For now, this is just a placeholder so we can build the frame and routing.
      </p>
    </div>
  );
}
