/* FILE: src/scenes/CorridorScene.tsx
   Placeholder implementation:
   The full hybrid arcane/digital corridor will be implemented later.
   For now, this is a simple stub so the project compiles.
*/

export function CorridorScene() {
  return (
    <div style={{ color: "white", padding: "1rem" }}>
      Corridor Scene placeholder – corridor engine coming soon.
    </div>
  );
}
