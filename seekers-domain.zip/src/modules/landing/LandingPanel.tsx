// src/modules/landing/LandingPanel.tsx
import React, { useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OakDoorExperience } from "../../scenes/OakDoorScene";
import { useNavigate } from "react-router-dom";

const LandingPanel: React.FC = () => {
  const [showCinematic, setShowCinematic] = useState(false);
  const navigate = useNavigate();

  const handlePortalReady = () => {
    setShowCinematic(true);
  };

  const handleCinematicEnd = () => {
    // 🔍 Decide: is this a new Seeker or a returning one?
    const profile = readSeekerProfile();

    if (profile && profile.seekerName && profile.seekerName.trim().length > 0) {
      // Returning Seeker → go straight to their Codex
      navigate("/codex");
    } else {
      // No stored profile → treat as new → onboarding flow
      navigate("/onboarding");
    }
  };

  // Typed cast: OakDoorExperience accepts an optional onPortalReady callback prop
  const OakDoor = OakDoorExperience as React.ComponentType<{ onPortalReady?: () => void }>;

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%",
        backgroundColor: "#000008",
        overflow: "hidden",
      }}
    >
        <OakDoor onPortalReady={handlePortalReady} />
      <Canvas shadows camera={{ position: [0, 1.6, 4], fov: 50 }}>
        <color attach="background" args={["#000008"]} />
        <OakDoor onPortalReady={handlePortalReady} />
      </Canvas>

      {/* Wormhole cinematic overlay */}
      {showCinematic && (
        <video
          src="/media/wormhole_cinematic.mp4"
          autoPlay
          onEnded={handleCinematicEnd}
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            backgroundColor: "black",
          }}
        />
      )}
    </div>
  );
};

export default LandingPanel;

// ---- Helper: read seeker profile from localStorage ----

interface StoredSeekerProfile {
  seekerName?: string;
  mbtiType?: string;
  seekerStone?: string | null;
  sealNotes?: string;
}

function readSeekerProfile(): StoredSeekerProfile | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("hyperverse_seeker_profile");
    if (!raw) return null;
    return JSON.parse(raw) as StoredSeekerProfile;
  } catch {
    return null;
  }
}
