export function StudioPanel() {
  return (
    <div>
      <h1 style={{ color: "#4effff", marginBottom: 12 }}>Creator Studio</h1>
      <p style={{ maxWidth: 600, lineHeight: 1.6 }}>
        This will become the multi-window Creator’s Digital Studio where nodes zoom in and out.
        Right now we’re just wiring the slot where that experience will live.
      </p>
    </div>
  );
}
